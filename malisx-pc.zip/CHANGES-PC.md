# malisx-pc

Fork of [malisx2](https://github.com/bmdhacks/malisx2) 0.5.0 (MIT, by bmdhacks)
for Mali-G52 (v7) PC/DXVK work. ARMSX2 behaviour must not regress.

## Changes from malisx2 0.5.0
- 0.5.0-pc1: nested `vkMapMemory` is tolerated (returns the same view, counted
  by `map_count`) instead of failing with VK_ERROR_MEMORY_MAP_FAILED.
  Fixes FauxVKTest `compat.nested_map`.
