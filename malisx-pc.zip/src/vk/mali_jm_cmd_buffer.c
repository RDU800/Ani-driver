/*
 * SPDX-FileCopyrightText: 2026 ARMSX2 and bmdhacks
 * SPDX-License-Identifier: MIT
 */

/*
 * The job-manager (v7 and v9) command buffer: command memory, batches and
 * job chains, job writing and linking, barriers, begin/end, and what a
 * command buffer that runs more than once needs restored.
 *
 * Every vkCmd* writes finished jobs when it is recorded, except a v7 draw's
 * Tiler job, whose header and link are written when it goes into the chain
 * (mali_v7_link_tilers), at the latest when the batch closes. A command
 * buffer is a list of batches (mali_jm.h); a batch is one vertex/tiler/
 * compute ("vtc") job chain, which runs as one atom on job slot 1, and
 * fragment segments, each a fragment chain that runs as one atom on slot 0
 * after the vtc atom. Submit (mali_jm_queue.c) only numbers the atoms and
 * fills in their dependencies.
 *
 * Linking follows Mesa (pan_jc.h pan_jc_add_job): every job of a chain
 * takes the next index (unique and increasing), a tiler-side job depends
 * on the previous tiler-side job through Dependency 2, and the previous
 * job's Next is written once the next job exists. All of it is stores to
 * write-combined command memory; nothing is read back. The queue's
 * "dsb st" before JOB_SUBMIT makes them visible.
 *
 * Barriers are applied lazily, per job slot: a barrier records what the
 * next vtc job and the next fragment job have to wait for, and the
 * requirement is resolved when such a job is recorded:
 *
 *  - vtc after vtc: the Barrier bit on the next job of the vtc chain, after
 *    a Cache Flush job ("Invalidate Shader Core Other") when the reads go
 *    through a shader core's read-only caches. Nothing when the chain is
 *    still empty: atoms of one slot run in order, and the kernel cleans
 *    and invalidates the caches between atoms;
 *  - vtc after fragment: a vtc chain runs before its batch's fragment
 *    chains, so the batch is closed if it has fragment work, and the next
 *    batch's vtc atom waits for the newest fragment atom; a batch without
 *    fragment work waits for the newest earlier fragment atom instead,
 *    which the queue resolves at submit. A barrier whose fragment-slot
 *    source stages are only transfer stages asks only for fragment atoms
 *    that carried transfer work (fragment-side copies, blits, clears), so
 *    an upload barrier does not hold the next frame's tiling behind the
 *    previous frame's fragment work. A barrier whose vtc-slot destination
 *    stages are only transfer stages asks this only of the next transfer
 *    done by compute (mali_jm_cmd_vtc_transfer), not of draws and
 *    dispatches, which are outside its second scope: a "colour output ->
 *    transfer" barrier for a fragment-side image copy then does not close
 *    the batch at the next pass's tiling. On v7 the requirement of an image
 *    memory barrier (image_barrier_req) is waited for only by the vtc jobs
 *    that can touch images or memory (transfers, dispatches, draws whose
 *    vertex shader reads images or writes memory), not by a pass's tiling;
 *    the pass still starts its own batch where the plain requirement would
 *    have closed the open one, so its tiling runs while the fragment work
 *    before it shades;
 *  - fragment after vtc: free inside a batch (its fragment atoms depend on
 *    its vtc atom); a batch without a vtc chain waits for the newest vtc
 *    atom;
 *  - fragment after fragment: the Barrier bit (and Cache Flush job) on the
 *    next job of the current fragment segment.
 *
 * What is still owed when the command buffer ends goes to the queue
 * (mali_jm_cmd::end_req), which applies it to the next atoms of later
 * command buffers, as a barrier's second scope requires; a transfer-only
 * requirement there, again only to the next vtc chain with a transfer job,
 * and on v7 an image barrier's to the next one that can touch images.
 */

#include "mali_cmd_state.h"

#include <stdalign.h>
#include <stdlib.h>
#include <string.h>

#include "util/log.h"
#include "vk_alloc.h"
#include "vk_command_pool.h"
#include "vk_log.h"
#include "vk_synchronization.h"

#include "mali_measure.h"

/* ---------------------------------------------------------------------- */
/* Memory                                                                  */

/* Free slabs the device keeps for reuse, as on v11 (mali_cmd_buffer.c):
 * the same device list, freed at device destruction by
 * mali_cmd_slabs_finish. */
#define MALI_CMD_FREE_SLABS_MAX 512

/* v7: blocks larger than half a slab and at most 1 MiB, such as a draw's
 * varying buffers (vertex count times varying stride), are carved from
 * 1 MiB slabs the device keeps for reuse instead of a dedicated BO each,
 * which costs an mmap and a GPU MMU update per allocation and an munmap
 * and MMU flush per reset. Big slabs sit at the tail of free_slabs,
 * standard ones at the head; at most this many big ones are kept. */
#define MALI_CMD_BIG_SLAB_SIZE (1024 * 1024)
#define MALI_CMD_FREE_BIG_SLABS_MAX 32

/* A slab of command memory: CPU and GPU read/write (the GPU writes job
 * headers back), CPU-uncached, written and never read by the CPU. */
static struct mali_cmd_slab *
slab_new(struct mali_device *dev, uint64_t size, bool recycle)
{
   if (recycle) {
      simple_mtx_lock(&dev->slab_lock);
      struct mali_cmd_slab *s = NULL;
      if (!list_is_empty(&dev->free_slabs)) {
#if PAN_ARCH < 9
         /* Standard slabs at the head, big ones at the tail. */
         struct list_head *e = size == MALI_CMD_SLAB_SIZE ? dev->free_slabs.next
                                                           : dev->free_slabs.prev;
         s = list_entry(e, struct mali_cmd_slab, link);
         if (s->bo.size != size) {
            s = NULL;
         } else {
            list_del(&s->link);
            dev->free_slab_count--;
            if (size != MALI_CMD_SLAB_SIZE)
               dev->jm->free_big_slabs--;
         }
#else
         s = list_first_entry(&dev->free_slabs, struct mali_cmd_slab, link);
         list_del(&s->link);
         dev->free_slab_count--;
#endif
      }
      simple_mtx_unlock(&dev->slab_lock);
      if (s)
         return s;
   }

   struct mali_cmd_slab *s = calloc(1, sizeof(*s));
   if (!s)
      return NULL;
   const struct mali_kbase_alloc_info ai = {
      .size = size,
      .flags = mali_kbase_mem_same_va_policy(MALI_KBASE_FLAGS_DEVICE_UNCACHED),
      .mem_class = MALI_KBASE_MEM_CLASS_COMMAND_ALLOCATOR,
   };
   if (mali_kbase_alloc(dev->kbase, &ai, &s->bo) != MALI_KBASE_SUCCESS) {
      free(s);
      return NULL;
   }
   s->recycle = recycle;
   return s;
}

static void
slab_release(struct mali_device *dev, struct mali_cmd_slab *s)
{
   if (s->recycle) {
      simple_mtx_lock(&dev->slab_lock);
#if PAN_ARCH < 9
      if (s->bo.size != MALI_CMD_SLAB_SIZE) {
         if (dev->jm->free_big_slabs < MALI_CMD_FREE_BIG_SLABS_MAX &&
             dev->free_slab_count < MALI_CMD_FREE_SLABS_MAX) {
            list_addtail(&s->link, &dev->free_slabs);
            dev->free_slab_count++;
            dev->jm->free_big_slabs++;
            s = NULL;
         }
      } else
#endif
      if (dev->free_slab_count < MALI_CMD_FREE_SLABS_MAX) {
         list_add(&s->link, &dev->free_slabs);
         dev->free_slab_count++;
         s = NULL;
      }
      simple_mtx_unlock(&dev->slab_lock);
      if (!s)
         return;
   }
   mali_kbase_free(dev->kbase, &s->bo);
   free(s);
}

/* Command memory, and the TLS/WLS buffers the builders put on the same
 * list (recycle false). */
static void
release_memory(struct mali_cmd_buffer *cmd)
{
   list_for_each_entry_safe(struct mali_cmd_slab, s, &cmd->slabs, link) {
      list_del(&s->link);
      slab_release(cmd->dev, s);
   }
   cmd->cur = NULL;
   cmd->cur_offset = 0;
   cmd->cur_cpu = NULL;
   cmd->cur_gpu = 0;
#if PAN_ARCH < 9
   cmd->big_cpu = NULL;
   cmd->big_gpu = 0;
   cmd->big_offset = 0;
#endif
   cmd->tls.size = 0;
   cmd->tls.gpu = 0;
}

struct mali_ptr
MALI_PER_ARCH(cmd_alloc_slow)(struct mali_cmd_buffer *cmd, uint64_t size, uint64_t align)
{
   assert(util_is_power_of_two_nonzero64(align) && align <= 4096);
   size = MAX2(size, 1);

   if (size > MALI_CMD_SLAB_SIZE / 2) {
#if PAN_ARCH < 9
      if (size <= MALI_CMD_BIG_SLAB_SIZE) {
         uint64_t boff = ALIGN_POT(cmd->big_offset, align);
         if (!cmd->big_cpu || boff + size > MALI_CMD_BIG_SLAB_SIZE) {
            struct mali_cmd_slab *s = slab_new(cmd->dev, MALI_CMD_BIG_SLAB_SIZE, true);
            if (!s)
               goto oom;
            list_addtail(&s->link, &cmd->slabs);
            cmd->big_cpu = s->bo.cpu;
            cmd->big_gpu = s->bo.gpu_va;
            boff = 0;
         }
         cmd->big_offset = boff + size;
         return (struct mali_ptr){cmd->big_cpu + boff, cmd->big_gpu + boff};
      }
#endif
      struct mali_cmd_slab *s = slab_new(cmd->dev, size, false);
      if (!s)
         goto oom;
      list_addtail(&s->link, &cmd->slabs);
      return (struct mali_ptr){s->bo.cpu, s->bo.gpu_va};
   }

   uint64_t off = ALIGN_POT(cmd->cur_offset, align);
   if (!cmd->cur || off + size > MALI_CMD_SLAB_SIZE) {
      struct mali_cmd_slab *s = slab_new(cmd->dev, MALI_CMD_SLAB_SIZE, true);
      if (!s)
         goto oom;
      list_addtail(&s->link, &cmd->slabs);
      cmd->cur = s;
      cmd->cur_cpu = s->bo.cpu;
      cmd->cur_gpu = s->bo.gpu_va;
      off = 0;
   }
   cmd->cur_offset = off + size;
   return (struct mali_ptr){cmd->cur_cpu + off, cmd->cur_gpu + off};

oom:
   vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_DEVICE_MEMORY);
   return (struct mali_ptr){0};
}

#if PAN_ARCH < 9
/* ---------------------------------------------------------------------- */
/* The varying arena of indirect draws (mali_jm.h)                         */

struct mali_cmd_slab *
mali_v7_idraw_arena(struct mali_cmd_buffer *cmd)
{
   if (cmd->jm.idraw_arena)
      return cmd->jm.idraw_arena;
   struct mali_device *dev = cmd->dev;
   struct mali_jm_device *jd = dev->jm;
   struct mali_cmd_slab *s = NULL;

   simple_mtx_lock(&dev->slab_lock);
   if (!list_is_empty(&jd->idraw_arenas)) {
      s = list_first_entry(&jd->idraw_arenas, struct mali_cmd_slab, link);
      list_del(&s->link);
      jd->idraw_arena_count--;
   }
   simple_mtx_unlock(&dev->slab_lock);
   if (!s)
      s = slab_new(dev, MALI_V7_IDRAW_ARENA_SIZE, false);
   if (!s) {
      vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_DEVICE_MEMORY);
      return NULL;
   }
   memset(s->bo.cpu, 0, sizeof(struct mali_jm_idraw_arena_hdr));
   mali_jm_cmd_note_reset(cmd, s->bo.cpu, NULL, sizeof(struct mali_jm_idraw_arena_hdr));
   cmd->jm.idraw_arena = s;
   return s;
}

void
mali_v7_idraw_arena_release(struct mali_cmd_buffer *cmd)
{
   struct mali_cmd_slab *s = cmd->jm.idraw_arena;
   if (!s)
      return;
   cmd->jm.idraw_arena = NULL;
   struct mali_device *dev = cmd->dev;
   struct mali_jm_device *jd = dev->jm;

   /* The command buffer is not pending (a reset or a destruction): the
    * count is its last run's. */
   struct mali_jm_idraw_arena_hdr h;
   memcpy(&h, s->bo.cpu, sizeof(h));
   bool keep = false, say = false;
   if (jd) {
      simple_mtx_lock(&dev->slab_lock);
      if (h.dropped && !jd->idraw_dropped_said)
         say = jd->idraw_dropped_said = true;
      if (jd->idraw_arena_count < MALI_V7_IDRAW_ARENAS_KEPT) {
         list_add(&s->link, &jd->idraw_arenas);
         jd->idraw_arena_count++;
         keep = true;
      }
      simple_mtx_unlock(&dev->slab_lock);
   }
   if (say)
      mesa_logw("malisx2: %u indirect draws were skipped: their varyings did not fit the "
                "command buffer's %u MiB of varying memory for indirect draws",
                h.dropped, MALI_V7_IDRAW_ARENA_SIZE >> 20);
   if (!keep) {
      mali_kbase_free(dev->kbase, &s->bo);
      free(s);
   }
}

void
mali_v7_idraw_arenas_finish(struct mali_device *dev)
{
   struct mali_jm_device *jd = dev->jm;
   list_for_each_entry_safe(struct mali_cmd_slab, s, &jd->idraw_arenas, link) {
      list_del(&s->link);
      mali_kbase_free(dev->kbase, &s->bo);
      free(s);
   }
   jd->idraw_arena_count = 0;
}
#endif

/* ---------------------------------------------------------------------- */
/* Re-submission                                                           */

void
mali_jm_cmd_note_reset(struct mali_cmd_buffer *cmd, void *dst, const void *tmpl, uint32_t size)
{
   if (!cmd->jm.resubmit)
      return;
   struct mali_jm_reset r = {.dst = dst, .data_off = UINT32_MAX, .size = size};
   if (tmpl) {
      r.data_off = util_dynarray_num_elements(&cmd->jm.reset_data, uint8_t);
      void *d = util_dynarray_grow_bytes(&cmd->jm.reset_data, 1, size);
      if (!d) {
         vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_HOST_MEMORY);
         return;
      }
      memcpy(d, tmpl, size);
   }
   struct mali_jm_reset *slot = util_dynarray_grow(&cmd->jm.resets, struct mali_jm_reset, 1);
   if (slot)
      *slot = r;
   else
      vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_HOST_MEMORY);
}

/* The job manager writes a job's Exception Status, First Incomplete Task
 * and Fault Pointer (header words 0-3) when it runs the job, and refuses
 * to run a job whose status is not zero; the rest of the header is ours
 * (panvk JM and the T820 blob reset the same words). Other
 * GPU-written words (tiler contexts, heap descriptors, the draw
 * descriptor's Vertex array words) are noted by the code that writes
 * them. */
void
mali_jm_cmd_prepare_submit(struct mali_cmd_buffer *cmd)
{
   if (!cmd->jm.resubmit || !cmd->jm.submitted)
      return;
   const uint8_t *data = util_dynarray_begin(&cmd->jm.reset_data);
   util_dynarray_foreach(&cmd->jm.resets, struct mali_jm_reset, r) {
      if (r->data_off == UINT32_MAX)
         memset(r->dst, 0, r->size);
      else
         memcpy(r->dst, data + r->data_off, r->size);
   }
}

/* ---------------------------------------------------------------------- */
/* Jobs                                                                    */

static inline bool
job_is_tiler_side(enum mali_job_type type)
{
#if PAN_ARCH >= 9
   return type == MALI_JOB_TYPE_MALLOC_VERTEX || type == MALI_JOB_TYPE_FULLSCREEN ||
          type == MALI_JOB_TYPE_TILER;
#else
   /* v7 has no Malloc Vertex or Fullscreen jobs: a draw is a Vertex job
    * (compute side) and a Tiler job that depends on it. */
   return type == MALI_JOB_TYPE_TILER;
#endif
}

/* Header and link of a job at job (size bytes, from command memory), on
 * the tiler side or not. */
static inline void
link_job_side(struct mali_cmd_buffer *cmd, struct mali_jm_chain *c, struct mali_ptr job,
              enum mali_job_type type, bool barrier, uint16_t dep1, bool tiler_side)
{
   const uint16_t index = ++c->index;

   pan_cast_and_pack(job.cpu, JOB_HEADER, h) {
      h.type = type;
      h.barrier = barrier;
      h.index = index;
      h.dependency_1 = dep1;
      h.dependency_2 = tiler_side ? c->tiler_dep : 0;
   }
   mali_jm_chain_link(c, job, index, tiler_side);
   mali_jm_cmd_note_reset(cmd, job.cpu, NULL, 16);
}

static inline void
link_job(struct mali_cmd_buffer *cmd, struct mali_jm_chain *c, struct mali_ptr job,
         enum mali_job_type type, bool barrier, uint16_t dep1)
{
   link_job_side(cmd, c, job, type, barrier, dep1, job_is_tiler_side(type));
}

/* Room for one more job in the chain's 16-bit index space, with a Cache
 * Flush job in front of it. */
static inline bool
chain_has_room(struct mali_cmd_buffer *cmd, const struct mali_jm_chain *c)
{
   if (likely(c->index < UINT16_MAX - 2))
      return true;
   mesa_loge("malisx2: a job chain ran out of job indices (%u jobs)", c->jobs);
   vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_DEVICE_MEMORY);
   return false;
}

#if PAN_ARCH < 9
void
mali_v7_link_tilers(struct mali_cmd_buffer *cmd, unsigned keep)
{
   struct mali_jm_cmd *jm = &cmd->jm;
   if (jm->pend_tilers <= keep)
      return;
   assert(jm->open);
   struct mali_jm_chain *c = &jm->cur.vtc;
   const unsigned n = jm->pend_tilers - keep;
   for (unsigned i = 0; i < n; i++) {
      if (!chain_has_room(cmd, c))
         break;
      /* An indirect draw's Tiler job: Not Started until its patch job
       * writes the type, a tiler-side job all the same. */
      const bool ns = jm->pend_tiler_ns & BITFIELD_BIT(i);
      link_job_side(cmd, c, jm->pend_tiler[i],
                    ns ? MALI_JOB_TYPE_NOT_STARTED : MALI_JOB_TYPE_TILER, false,
                    jm->pend_tiler_dep1[i], true);
   }
   for (unsigned i = 0; i < keep; i++) {
      jm->pend_tiler[i] = jm->pend_tiler[n + i];
      jm->pend_tiler_dep1[i] = jm->pend_tiler_dep1[n + i];
   }
   jm->pend_tiler_ns >>= n;
   jm->pend_tilers = keep;
}
#endif

bool
mali_jm_cmd_add_job_at(struct mali_cmd_buffer *cmd, struct mali_jm_chain *c,
                       struct mali_ptr job, enum mali_job_type type, bool barrier,
                       uint16_t dep1)
{
#if PAN_ARCH < 9
   if (unlikely(cmd->jm.pend_tilers) && !cmd->jm.tiler_defer)
      mali_v7_link_tilers(cmd, 0);
#endif
   if (!chain_has_room(cmd, c))
      return false;

   if (unlikely(c->pending)) {
      if (c->pending & MALI_JM_PENDING_FLUSH) {
         struct mali_ptr f = mali_cmd_alloc(cmd, pan_size(CACHE_FLUSH_JOB), 128);
         if (!f.cpu)
            return false;
         link_job(cmd, c, f, MALI_JOB_TYPE_CACHE_FLUSH, true, 0);
         pan_section_pack(f.cpu, CACHE_FLUSH_JOB, PAYLOAD, p) {
            p.invalidate_shader_core_other = true;
         }
      }
      barrier = true;
      c->pending = 0;
   }

   link_job(cmd, c, job, type, barrier, dep1);
   return true;
}

struct mali_ptr
mali_jm_cmd_add_job(struct mali_cmd_buffer *cmd, struct mali_jm_chain *c,
                    enum mali_job_type type, unsigned size, bool barrier, uint16_t dep1)
{
#if PAN_ARCH < 9
   /* Every job but a draw's copy jobs and its Vertex job, which go in
    * while tiler_defer is set (mali_jm_cmd_draw_v7.c), goes in behind the
    * pending Tiler jobs. */
   if (unlikely(cmd->jm.pend_tilers) && !cmd->jm.tiler_defer)
      mali_v7_link_tilers(cmd, 0);
#endif
   if (!chain_has_room(cmd, c))
      return (struct mali_ptr){0};

   if (unlikely(c->pending)) {
      if (c->pending & MALI_JM_PENDING_FLUSH) {
         struct mali_ptr f = mali_cmd_alloc(cmd, pan_size(CACHE_FLUSH_JOB), 128);
         if (!f.cpu)
            return f;
         link_job(cmd, c, f, MALI_JOB_TYPE_CACHE_FLUSH, true, 0);
         pan_section_pack(f.cpu, CACHE_FLUSH_JOB, PAYLOAD, p) {
            p.invalidate_shader_core_other = true;
         }
      }
      barrier = true;
      c->pending = 0;
   }

   struct mali_ptr job = mali_cmd_alloc(cmd, size, 128);
   if (!job.cpu)
      return job;
   link_job(cmd, c, job, type, barrier, dep1);
   return job;
}

bool
mali_jm_cmd_write_value(struct mali_cmd_buffer *cmd, struct mali_jm_chain *c,
                        enum mali_write_value_type type, uint64_t addr, uint64_t value,
                        bool barrier)
{
   struct mali_ptr j =
      mali_jm_cmd_add_job(cmd, c, MALI_JOB_TYPE_WRITE_VALUE, pan_size(WRITE_VALUE_JOB),
                          barrier, 0);
   if (!j.cpu)
      return false;
   if (type == MALI_WRITE_VALUE_TYPE_SYSTEM_TIMESTAMP)
      c->timestamps = true;
   pan_section_pack(j.cpu, WRITE_VALUE_JOB, PAYLOAD, p) {
      p.address = addr;
      p.type = type;
      p.immediate_value = value;
   }
   return true;
}

/* ---------------------------------------------------------------------- */
/* Batches                                                                 */

/* Barrier requirements of mali_jm_cmd::req (lazily applied, file comment).
 * VTC_*: what the next vtc job waits for; FRAG_*: the next fragment job. */
#define REQ_VTC_AFTER_VTC       (1u << 0)
#define REQ_VTC_AFTER_FRAG      (1u << 1)   /* every earlier fragment atom */
#define REQ_VTC_AFTER_FRAG_XFER (1u << 2)   /* earlier fragment-side transfers */
#define REQ_VTC_FLUSH           (1u << 3)
#define REQ_FRAG_AFTER_VTC      (1u << 4)
#define REQ_FRAG_AFTER_FRAG     (1u << 5)
#define REQ_FRAG_FLUSH          (1u << 6)
/* The VTC_AFTER_FRAG requirements of barriers whose vtc-slot destination
 * stages are only transfer stages: only the next transfer job on the vtc
 * chain (mali_jm_cmd_vtc_transfer) waits for them. */
#define REQ_XVTC_AFTER_FRAG      (1u << 7)
#define REQ_XVTC_AFTER_FRAG_XFER (1u << 8)
#if PAN_ARCH < 9
/* v7: the VTC_AFTER_FRAG requirements of image memory barriers
 * (image_barrier_req), which the vtc jobs that can touch an image wait
 * for: transfers, dispatches (mali_jm_cmd_vtc) and draws whose vertex
 * shader reads textures or images or writes memory
 * (mali_jm_cmd_pass_images). Not the tiling of a pass, and not Write Value
 * jobs. REQ_IVTC_SPLIT goes with them until the next pass that tiles:
 * that pass's tiling starts a new batch if the open one has fragment work
 * the requirement is about (mali_jm_cmd_vtc_draw). */
#define REQ_IVTC_AFTER_FRAG      (1u << 9)
#define REQ_IVTC_AFTER_FRAG_XFER (1u << 10)
#define REQ_IVTC_SPLIT           (1u << 11)
#else
#define REQ_IVTC_AFTER_FRAG      0
#define REQ_IVTC_AFTER_FRAG_XFER 0
#define REQ_IVTC_SPLIT           0
#endif

#define REQ_VTC_ALL                                                            \
   (REQ_VTC_AFTER_VTC | REQ_VTC_AFTER_FRAG | REQ_VTC_AFTER_FRAG_XFER | REQ_VTC_FLUSH)
#define REQ_XVTC_ALL (REQ_XVTC_AFTER_FRAG | REQ_XVTC_AFTER_FRAG_XFER)
#define REQ_IVTC_ALL (REQ_IVTC_AFTER_FRAG | REQ_IVTC_AFTER_FRAG_XFER)

/* What a job on the vtc chain waits for, besides the plain requirements. */
enum vtc_job {
   VTC_JOB_PLAIN,   /* the tiling of a pass, Write Value jobs */
   VTC_JOB_XFER,    /* a transfer by compute: also REQ_XVTC_*, and on v7 REQ_IVTC_* */
#if PAN_ARCH < 9
   VTC_JOB_IMAGE,   /* a dispatch, a draw that can touch images or memory: REQ_IVTC_* */
   VTC_JOB_FRESH,   /* a copy into a fresh image: the plain ones only */
#endif
};

static inline bool
batch_has_frag_jobs(const struct mali_cmd_buffer *cmd)
{
   const struct mali_jm_frag_seg *segs = util_dynarray_begin(&cmd->jm.frags);
   for (uint32_t i = 0; i < cmd->jm.cur.frag_count; i++)
      if (segs[cmd->jm.cur.frag_first + i].chain.jobs)
         return true;
   return false;
}

struct mali_jm_batch *
mali_jm_cmd_batch(struct mali_cmd_buffer *cmd)
{
   if (likely(cmd->jm.open))
      return &cmd->jm.cur;
   cmd->jm.cur = (struct mali_jm_batch){
      .frag_first = util_dynarray_num_elements(&cmd->jm.frags, struct mali_jm_frag_seg),
      .heap_slot = -1,
   };
   cmd->jm.open = true;
   return &cmd->jm.cur;
}

void
mali_jm_cmd_batch_close(struct mali_cmd_buffer *cmd)
{
   if (!cmd->jm.open)
      return;
#if PAN_ARCH < 9
   mali_v7_link_tilers(cmd, 0);
#endif
   cmd->jm.open = false;
   struct mali_jm_batch *b = &cmd->jm.cur;
   if (!b->vtc.jobs && !batch_has_frag_jobs(cmd)) {
      /* Nothing recorded: no atoms. Its (empty) segments go too. */
      cmd->jm.frags.size = b->frag_first * sizeof(struct mali_jm_frag_seg);
      return;
   }
   if (!b->vtc.jobs)
      b->vtc = (struct mali_jm_chain){0};
   struct mali_jm_batch *slot = util_dynarray_grow(&cmd->jm.batches, struct mali_jm_batch, 1);
   if (slot)
      *slot = *b;
   else
      vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_HOST_MEMORY);
}

/* The requirements on the next vtc job, with the ones its kind also waits
 * for folded into the plain bits. */
static inline uint16_t
vtc_req(uint16_t req, enum vtc_job job)
{
   uint16_t want = req & REQ_VTC_ALL;
   if (job == VTC_JOB_XFER) {
      if (req & REQ_XVTC_AFTER_FRAG)
         want |= REQ_VTC_AFTER_FRAG;
      if (req & REQ_XVTC_AFTER_FRAG_XFER)
         want |= REQ_VTC_AFTER_FRAG_XFER;
   }
#if PAN_ARCH < 9
   if (job == VTC_JOB_XFER || job == VTC_JOB_IMAGE) {
      if (req & REQ_IVTC_AFTER_FRAG)
         want |= REQ_VTC_AFTER_FRAG;
      if (req & REQ_IVTC_AFTER_FRAG_XFER)
         want |= REQ_VTC_AFTER_FRAG_XFER;
   }
#endif
   return want;
}

/* Does meeting req on the vtc chain close the open batch? */
static inline bool
vtc_req_closes(const struct mali_cmd_buffer *cmd, uint16_t req)
{
   if (req & REQ_VTC_AFTER_FRAG)
      return batch_has_frag_jobs(cmd);
   if (req & REQ_VTC_AFTER_FRAG_XFER)
      return cmd->jm.cur.frag_xfer;
   return false;
}

static struct mali_jm_chain *
vtc_chain(struct mali_cmd_buffer *cmd, enum vtc_job job)
{
   struct mali_jm_batch *b = mali_jm_cmd_batch(cmd);
   const uint16_t req = vtc_req(cmd->jm.req, job);

   /* Outside a render pass, a full batch closes before the next job. */
   if (unlikely(b->vtc.jobs >= MALI_JM_BATCH_MAX_JOBS) && !cmd->gfx.render.active) {
      mali_jm_cmd_batch_close(cmd);
      b = mali_jm_cmd_batch(cmd);
   }

   if (unlikely(req)) {
      if (req & (REQ_VTC_AFTER_FRAG | REQ_VTC_AFTER_FRAG_XFER)) {
         /* Fragment work of this batch runs after its vtc chain: if the
          * barrier waits for some, the batch ends here. */
         if (vtc_req_closes(cmd, req)) {
            mali_jm_cmd_batch_close(cmd);
            b = mali_jm_cmd_batch(cmd);
            b->vtc_after_frag = MALI_JM_AFTER_EARLIER;
         } else if (req & REQ_VTC_AFTER_FRAG) {
            b->vtc_after_frag = MALI_JM_AFTER_EARLIER;
         } else if (b->vtc_after_frag != MALI_JM_AFTER_EARLIER) {
            b->vtc_after_frag = MALI_JM_AFTER_EARLIER_XFER;
         }
      }
      /* An empty chain is a new atom: the slot order and the kernel's
       * cache maintenance between atoms already do this. */
      if (b->vtc.jobs && (req & REQ_VTC_AFTER_VTC))
         b->vtc.pending |= MALI_JM_PENDING_BARRIER |
                           ((req & REQ_VTC_FLUSH) ? MALI_JM_PENDING_FLUSH : 0);
      /* The transfer-only and image requirements are met with the plain
       * ones: the batch's vtc atom now waits for every fragment atom they
       * name. */
      uint16_t met = REQ_VTC_ALL;
      if (req & REQ_VTC_AFTER_FRAG)
         met |= REQ_XVTC_ALL | REQ_IVTC_ALL;
      else if (req & REQ_VTC_AFTER_FRAG_XFER)
         met |= REQ_XVTC_AFTER_FRAG_XFER | REQ_IVTC_AFTER_FRAG_XFER;
      cmd->jm.req &= ~met;
#if PAN_ARCH < 9
      if (!(cmd->jm.req & REQ_XVTC_ALL))
         cmd->jm.xvtc_buf = false;
      if (!(cmd->jm.req & REQ_IVTC_ALL))
         cmd->jm.req &= ~REQ_IVTC_SPLIT;
#endif
   }
   if (job == VTC_JOB_XFER)
      b->vtc_xfer = true;
#if PAN_ARCH < 9
   if (job == VTC_JOB_XFER || job == VTC_JOB_IMAGE)
      b->vtc_img = true;
   if (job == VTC_JOB_FRESH)
      b->vtc_fresh = true;
#endif
   return &b->vtc;
}

struct mali_jm_chain *
mali_jm_cmd_vtc(struct mali_cmd_buffer *cmd)
{
#if PAN_ARCH < 9
   /* Dispatches: they write memory and may read an image that an
    * image-only barrier ordered (image_barrier_req). They are not in the
    * second scope of a transfer-only barrier. */
   return vtc_chain(cmd, VTC_JOB_IMAGE);
#else
   return vtc_chain(cmd, VTC_JOB_PLAIN);
#endif
}

struct mali_jm_chain *
mali_jm_cmd_vtc_draw(struct mali_cmd_buffer *cmd)
{
#if PAN_ARCH < 9
   /* The tiling of a pass does not wait for an image barrier's
    * requirement, but it still starts a new batch when the open one has
    * the fragment work that requirement is about: a batch's fragment atoms
    * wait for all of its tiling, and the next batch's tiling runs while
    * they shade. This is where a plain requirement would have closed the
    * batch, so the batches are the ones such a barrier always made, minus
    * the wait. Once per barrier (REQ_IVTC_SPLIT): later passes go into the
    * batch as usual. */
   if (cmd->jm.req & REQ_IVTC_SPLIT) {
      cmd->jm.req &= ~REQ_IVTC_SPLIT;
      if (cmd->jm.open &&
          vtc_req_closes(cmd, vtc_req(cmd->jm.req & REQ_IVTC_ALL, VTC_JOB_IMAGE)))
         mali_jm_cmd_batch_close(cmd);
   }
#endif
   return vtc_chain(cmd, VTC_JOB_PLAIN);
}

struct mali_jm_chain *
mali_jm_cmd_vtc_value(struct mali_cmd_buffer *cmd)
{
   return vtc_chain(cmd, VTC_JOB_PLAIN);
}

void
mali_jm_cmd_pass_images(struct mali_cmd_buffer *cmd)
{
#if PAN_ARCH < 9
   const uint16_t req = vtc_req(cmd->jm.req, VTC_JOB_IMAGE);
   /* The pass's tiling so far ran ahead of this batch's fragment work: the
    * draw goes on in a new batch, which waits for it. */
   if (vtc_req_closes(cmd, req))
      mali_jm_cmd_pass_split(cmd);
   vtc_chain(cmd, VTC_JOB_IMAGE);
#else
   (void)cmd;
#endif
}

struct mali_jm_chain *
mali_jm_cmd_vtc_transfer(struct mali_cmd_buffer *cmd)
{
#if PAN_ARCH < 9
   /* A copy into a fresh image (mali_image::fresh): no earlier work read
    * or wrote the image or its memory, so of the transfer-only
    * requirements it needs only those of buffer and global barriers (its
    * source buffer). Image barriers' requirements stay for the next job
    * that can touch their image. */
   if (cmd->jm.xfer_fresh && !cmd->jm.xvtc_buf)
      return vtc_chain(cmd, VTC_JOB_FRESH);
#endif
   return vtc_chain(cmd, VTC_JOB_XFER);
}

bool
mali_jm_cmd_transfer_needs_frag(struct mali_cmd_buffer *cmd)
{
   return cmd->jm.open && vtc_req_closes(cmd, vtc_req(cmd->jm.req, VTC_JOB_XFER));
}

struct mali_jm_chain *
mali_jm_cmd_frag(struct mali_cmd_buffer *cmd, bool new_segment)
{
   struct mali_jm_batch *b = mali_jm_cmd_batch(cmd);
   const uint16_t req = cmd->jm.req;

   /* A fragment -> fragment barrier with a cache flush, on a GPU whose
    * fragment job slot does not run Cache Flush jobs: a new fragment atom
    * instead. It follows the previous one in the slot order, and the
    * kernel flushes and invalidates the caches between atoms. */
   if (unlikely((req & REQ_FRAG_AFTER_FRAG) && (req & REQ_FRAG_FLUSH) &&
                !cmd->dev->jm->frag_cache_flush) && b->frag_count &&
       util_dynarray_element(&cmd->jm.frags, struct mali_jm_frag_seg,
                             b->frag_first + b->frag_count - 1)->chain.jobs)
      new_segment = true;

   if (new_segment || !b->frag_count) {
      struct mali_jm_frag_seg *seg =
         util_dynarray_grow(&cmd->jm.frags, struct mali_jm_frag_seg, 1);
      if (!seg) {
         vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_HOST_MEMORY);
         return NULL;
      }
      *seg = (struct mali_jm_frag_seg){0};
      b->frag_count++;
   }
   struct mali_jm_chain *c =
      &util_dynarray_element(&cmd->jm.frags, struct mali_jm_frag_seg,
                             b->frag_first + b->frag_count - 1)->chain;

   if (unlikely(req & (REQ_FRAG_AFTER_VTC | REQ_FRAG_AFTER_FRAG | REQ_FRAG_FLUSH))) {
      if (req & REQ_FRAG_AFTER_VTC)
         b->frag_after_vtc = true;
      if (c->jobs && (req & REQ_FRAG_AFTER_FRAG))
         c->pending |= MALI_JM_PENDING_BARRIER |
                       ((req & REQ_FRAG_FLUSH) ? MALI_JM_PENDING_FLUSH : 0);
      cmd->jm.req &= ~(REQ_FRAG_AFTER_VTC | REQ_FRAG_AFTER_FRAG | REQ_FRAG_FLUSH);
   }
   return c;
}

void
mali_jm_cmd_mark_frag_transfer(struct mali_cmd_buffer *cmd)
{
   mali_jm_cmd_batch(cmd)->frag_xfer = true;
}

bool
mali_jm_cmd_add_batch(struct mali_cmd_buffer *cmd, const struct mali_jm_batch *batch,
                      const struct mali_jm_frag_seg *frags, uint32_t frag_count)
{
   mali_jm_cmd_batch_close(cmd);
   struct mali_jm_batch b = *batch;
   b.frag_first = util_dynarray_num_elements(&cmd->jm.frags, struct mali_jm_frag_seg);
   b.frag_count = frag_count;
   if (frag_count) {
      struct mali_jm_frag_seg *f =
         util_dynarray_grow(&cmd->jm.frags, struct mali_jm_frag_seg, frag_count);
      if (!f)
         return false;
      memcpy(f, frags, frag_count * sizeof(*f));
   }
   struct mali_jm_batch *slot = util_dynarray_grow(&cmd->jm.batches, struct mali_jm_batch, 1);
   if (!slot)
      return false;
   *slot = b;
   return true;
}

/*
 * An event operation is a batch of its own, between the batches recorded
 * before it and those after, so each side's work is in other atoms than the
 * event's: closing the open batch is what lets the set's atom wait for the
 * work before it, and lets the work after a wait be held by the wait's
 * atom. A Write Value job in the vtc chain could not set the word: the
 * batch's fragment atoms run after its vtc atom, and the job's store is not
 * ordered against the cache clean the kernel does when an atom completes.
 *
 * Inside a render pass (a wait: a set or reset is not valid there) the pass
 * is split at the wait: its tiling so far is one vtc atom, the wait's atom
 * comes next, and the rest of the pass goes on in a new batch with the
 * same tiler heap. That batch's fragment work, which reads all of the
 * pass's polygon lists, must follow the first vtc atom even when the batch
 * gets no vtc job of its own after the wait: frag_after_vtc.
 */
bool
mali_jm_cmd_event(struct mali_cmd_buffer *cmd, uint8_t op, uint64_t addr,
                  VkPipelineStageFlags2 stages)
{
   const bool split = cmd->gfx.render.active && cmd->jm.open;
   if (split)
      mali_jm_cmd_pass_split(cmd);
   else
      mali_jm_cmd_batch_close(cmd);
   struct mali_jm_batch *slot = util_dynarray_grow(&cmd->jm.batches, struct mali_jm_batch, 1);
   if (!slot) {
      vk_command_buffer_set_error(&cmd->vk, VK_ERROR_OUT_OF_HOST_MEMORY);
      return false;
   }
   *slot = (struct mali_jm_batch){
      .heap_slot = -1,
      .event_op = op,
      .event_addr = addr,
      .event_stages = stages,
   };
   if (split)
      cmd->jm.cur.frag_after_vtc = true;
   return true;
}

/* ---------------------------------------------------------------------- */
/* Barriers                                                                */

/* On v7 a blit region that is a plain copy runs as the compute copy on the
 * vtc slot (mali_cmd_image.c blit_region_v7) and any other region as a
 * fragment pass, so the blit stage is a transfer on both slots
 * (FRAG_XFER_STAGES has it too). A synchronization2 mask can name the blit
 * stage without the copy stage. On v9 a blit is always a fragment pass. */
#if PAN_ARCH < 9
#define VTC_BLIT_STAGES VK_PIPELINE_STAGE_2_BLIT_BIT
#else
#define VTC_BLIT_STAGES 0
#endif

/* Stages whose work runs on the vtc slot: vertex and compute shading,
 * indirect and vertex input, and transfers done by compute (buffer copies,
 * fills, updates, buffer<->image copies, plain-copy blits on v7). */
#define VTC_STAGES                                                             \
   (VK_PIPELINE_STAGE_2_DRAW_INDIRECT_BIT | VK_PIPELINE_STAGE_2_INDEX_INPUT_BIT | \
    VK_PIPELINE_STAGE_2_VERTEX_ATTRIBUTE_INPUT_BIT | VK_PIPELINE_STAGE_2_VERTEX_SHADER_BIT | \
    VK_PIPELINE_STAGE_2_TESSELLATION_CONTROL_SHADER_BIT |                      \
    VK_PIPELINE_STAGE_2_TESSELLATION_EVALUATION_SHADER_BIT |                   \
    VK_PIPELINE_STAGE_2_GEOMETRY_SHADER_BIT | VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT | \
    VK_PIPELINE_STAGE_2_COPY_BIT | VK_PIPELINE_STAGE_2_CLEAR_BIT | VTC_BLIT_STAGES)

/* The vtc-slot stages that are transfers. */
#define VTC_XFER_STAGES                                                        \
   (VK_PIPELINE_STAGE_2_COPY_BIT | VK_PIPELINE_STAGE_2_CLEAR_BIT | VTC_BLIT_STAGES)

/* Stages of rendering on the fragment slot. */
#define FRAG_RENDER_STAGES                                                     \
   (VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT |                             \
    VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT |                                  \
    VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT |                              \
    VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT)

/* Transfers that may run on the fragment slot: fragment-side image copies,
 * blits, resolves and image clears (render passes with a frame shader). */
#define FRAG_XFER_STAGES                                                       \
   (VK_PIPELINE_STAGE_2_COPY_BIT | VK_PIPELINE_STAGE_2_BLIT_BIT |              \
    VK_PIPELINE_STAGE_2_RESOLVE_BIT | VK_PIPELINE_STAGE_2_CLEAR_BIT)

/* Destination accesses that read through a shader core's read-only caches
 * (texture and attachment reads), which a write elsewhere does not
 * update: the reads need an "Invalidate Shader Core Other" first. L2 is
 * shared and the load/store caches are coherent with it (panvk
 * add_memory_dependency). Host accesses need nothing here: the kernel
 * cleans and invalidates the caches at every atom's start and end. */
#define RO_L1_ACCESS                                                           \
   (VK_ACCESS_2_COLOR_ATTACHMENT_READ_BIT |                                    \
    VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_READ_BIT | VK_ACCESS_2_TRANSFER_READ_BIT | \
    VK_ACCESS_2_SHADER_SAMPLED_READ_BIT | VK_ACCESS_2_INPUT_ATTACHMENT_READ_BIT)

static uint16_t
barrier_req(VkPipelineStageFlags2 src_stages, VkPipelineStageFlags2 dst_stages,
            VkAccessFlags2 dst_access);

void
mali_jm_cmd_barrier(struct mali_cmd_buffer *cmd, VkPipelineStageFlags2 src_stages,
                    VkAccessFlags2 src_access, VkPipelineStageFlags2 dst_stages,
                    VkAccessFlags2 dst_access)
{
   (void)src_access;
   const uint16_t req = barrier_req(src_stages, dst_stages, dst_access);
   cmd->jm.req |= req;
#if PAN_ARCH < 9
   /* Not known to be about images only (mali_jm_cmd::xvtc_buf). */
   if (req & REQ_XVTC_ALL)
      cmd->jm.xvtc_buf = true;
#endif
}

#if PAN_ARCH < 9
/*
 * The vtc requirements of image memory barriers. Their memory dependency
 * covers only the image; what is global is the execution dependency. A vtc
 * job that cannot access the image and writes no memory cannot tell
 * whether it ran before the first scope's fragment work or after it: a
 * read of a buffer that work wrote needs a buffer or global memory
 * dependency, which keeps the full rule, and a write-after-read needs a
 * write. So the "vtc after fragment" requirements of an image barrier
 * (REQ_IVTC_*) are waited for only by the vtc jobs that can touch images
 * or memory: a pass whose vertex shaders read no textures or images and
 * write no memory tiles while the fragment work before it still runs. The
 * barrier's transfer-only requirements (REQ_XVTC_*) and the others stay as
 * barrier_req made them.
 *
 * Titles that end every render-to-texture pass with an "all commands ->
 * all commands" image barrier (hakuX) otherwise get no overlap between a
 * pass's tiling and the fragment work before it: on the Mali-G52 that
 * left about a quarter of the GPU's time serialised.
 */
static uint16_t
image_barrier_req(VkPipelineStageFlags2 src_stages, VkPipelineStageFlags2 dst_stages,
                  VkAccessFlags2 dst_access)
{
   uint16_t req = barrier_req(src_stages, dst_stages, dst_access);
   if (req & REQ_VTC_AFTER_FRAG)
      req = (req & ~REQ_VTC_AFTER_FRAG) | REQ_IVTC_AFTER_FRAG;
   if (req & REQ_VTC_AFTER_FRAG_XFER)
      req = (req & ~REQ_VTC_AFTER_FRAG_XFER) | REQ_IVTC_AFTER_FRAG_XFER;
   if (req & REQ_IVTC_ALL)
      req |= REQ_IVTC_SPLIT;
   return req;
}
#endif

static uint16_t
barrier_req(VkPipelineStageFlags2 src_stages, VkPipelineStageFlags2 dst_stages,
            VkAccessFlags2 dst_access)
{
   src_stages = vk_expand_src_stage_flags2(src_stages);
   dst_stages = vk_expand_dst_stage_flags2(dst_stages);
   dst_access = vk_filter_dst_access_flags2(dst_stages, dst_access);

   const bool src_vtc = src_stages & VTC_STAGES;
   const bool src_frag = src_stages & FRAG_RENDER_STAGES;
   const bool src_frag_xfer = src_stages & FRAG_XFER_STAGES;
   /* vtc-slot destination stages, and whether any of them is not a
    * transfer (then every vtc job is in the second scope, else only
    * transfer jobs are). */
   const bool dst_vtc = dst_stages & VTC_STAGES;
   const bool dst_vtc_all = dst_stages & VTC_STAGES & ~VTC_XFER_STAGES;
   const bool dst_frag = dst_stages & (FRAG_RENDER_STAGES | FRAG_XFER_STAGES);
   const bool flush = dst_access & RO_L1_ACCESS;

   uint16_t req = 0;
   if (dst_vtc) {
      if (src_vtc)
         req |= REQ_VTC_AFTER_VTC | (flush ? REQ_VTC_FLUSH : 0);
      if (src_frag)
         req |= dst_vtc_all ? REQ_VTC_AFTER_FRAG : REQ_XVTC_AFTER_FRAG;
      else if (src_frag_xfer)
         req |= dst_vtc_all ? REQ_VTC_AFTER_FRAG_XFER : REQ_XVTC_AFTER_FRAG_XFER;
   }
   if (dst_frag) {
      if (src_vtc)
         req |= REQ_FRAG_AFTER_VTC;
      if (src_frag || src_frag_xfer)
         req |= REQ_FRAG_AFTER_FRAG | (flush ? REQ_FRAG_FLUSH : 0);
   }
   return req;
}

#if PAN_ARCH < 9
/* Source accesses that can write buffer memory, once
 * vk_filter_src_access_flags2 has expanded MEMORY_WRITE and SHADER_WRITE
 * for the source stages: shader storage writes, transfer writes and host
 * writes. Attachment writes reach images only. */
#define BUFFER_WRITE_ACCESS                                                    \
   (VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT | VK_ACCESS_2_TRANSFER_WRITE_BIT |    \
    VK_ACCESS_2_HOST_WRITE_BIT)

/*
 * v7 fragment shaders read their pushed uniform buffer words from FAU,
 * which a copy job on the vtc chain fills (mali_v7_ubo_copy). A buffer or
 * global barrier that makes fragment-shader uniform reads wait for buffer
 * writes therefore orders that job too: its source accesses include
 * BUFFER_WRITE_ACCESS, and its destination stages include the fragment
 * shader with UNIFORM_READ among the accesses (MEMORY_READ includes it,
 * vk_filter_dst_access_flags2). SHADER_READ does not: vk.xml defines it
 * as sampled, storage and binding table reads, and synchronization1's
 * SHADER_READ, which the runtime passes on unchanged, never covered
 * uniform buffers either. A render-to-texture barrier writes only
 * attachments and is not one.
 */
static bool
ubo_copy_dep(VkPipelineStageFlags2 src_stages, VkAccessFlags2 src_access,
             VkPipelineStageFlags2 dst_stages, VkAccessFlags2 dst_access)
{
   src_stages = vk_expand_src_stage_flags2(src_stages);
   dst_stages = vk_expand_dst_stage_flags2(dst_stages);
   return (vk_filter_src_access_flags2(src_stages, src_access) & BUFFER_WRITE_ACCESS) &&
          (dst_stages & VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT) &&
          (vk_filter_dst_access_flags2(dst_stages, dst_access) & VK_ACCESS_2_UNIFORM_READ_BIT);
}
#endif

/*
 * Image barriers after which the image's CRCs may not describe its memory
 * (the same rule as on v11, mali_cmd_buffer.c): a transition from
 * UNDEFINED or PREINITIALIZED, or an acquire from an external or foreign
 * queue family, on level 0 of the colour aspect.
 */
static bool
image_barrier_invalidates_crc(const VkImageMemoryBarrier2 *m)
{
   if (m->subresourceRange.baseMipLevel != 0 ||
       !(m->subresourceRange.aspectMask & VK_IMAGE_ASPECT_COLOR_BIT))
      return false;
   if (m->oldLayout == VK_IMAGE_LAYOUT_UNDEFINED ||
       m->oldLayout == VK_IMAGE_LAYOUT_PREINITIALIZED)
      return true;
   return m->srcQueueFamilyIndex != m->dstQueueFamilyIndex &&
          (m->srcQueueFamilyIndex == VK_QUEUE_FAMILY_EXTERNAL ||
           m->srcQueueFamilyIndex == VK_QUEUE_FAMILY_FOREIGN_EXT);
}

void
mali_jm_cmd_dep_crc(struct mali_cmd_buffer *cmd, const VkDependencyInfo *info)
{
   for (uint32_t i = 0; i < info->imageMemoryBarrierCount; i++) {
      const VkImageMemoryBarrier2 *m = &info->pImageMemoryBarriers[i];
      if (image_barrier_invalidates_crc(m))
         MALI_PER_ARCH(cmd_crc_invalidate)(cmd, container_of(vk_image_from_handle(m->image),
                                                             struct mali_image, vk));
   }
}

/*
 * An in-pass by-region barrier that only orders attachment writes before
 * attachment and input attachment reads (local read, framebuffer fetch).
 * On v7 those reads are LD_TILE without resource tracking
 * (mali_nir_lower_input_attachments.c, nir load_tile_pan), which keeps
 * absolute pixel ordering: the read waits in the tile unit for every older
 * fragment of its pixel. The barrier's draw (cmd_fb_barrier: a primitive
 * barrier over the whole framebuffer) only adds a drain of every tile's
 * pipeline per barrier: hakuX's cockpit passes have about 22 of them, and
 * with every draw scissored to one pixel such a 640x720 pass still took
 * 4.1 ms of fragment time on the G52. Storage and other memory accesses
 * keep the barrier, and so does a barrier that orders execution only (no
 * access in either scope): its masks say nothing about what it orders, so
 * the draw stays.
 */
#define TILE_SRC_ACCESS                                                        \
   (VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_2_COLOR_ATTACHMENT_READ_BIT | \
    VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT |                           \
    VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_READ_BIT)
#define TILE_DST_ACCESS                                                        \
   (TILE_SRC_ACCESS | VK_ACCESS_2_INPUT_ATTACHMENT_READ_BIT)

#if PAN_ARCH < 9
/* A barrier with no access in either scope, once the masks are filtered for
 * its stages: an execution dependency only. */
static bool
execution_only(VkPipelineStageFlags2 src, VkAccessFlags2 srca, VkPipelineStageFlags2 dst,
               VkAccessFlags2 dsta)
{
   src = vk_expand_src_stage_flags2(src);
   dst = vk_expand_dst_stage_flags2(dst);
   return !vk_filter_src_access_flags2(src, srca) && !vk_filter_dst_access_flags2(dst, dsta);
}
#endif

/* The masks are the unions over the call's barriers; exec_only says whether
 * any one of those barriers orders execution only. */
static bool
tile_ordered_barrier(VkPipelineStageFlags2 src, VkAccessFlags2 srca, VkPipelineStageFlags2 dst,
                     VkAccessFlags2 dsta, bool exec_only)
{
#if PAN_ARCH < 9
   if (exec_only)
      return false;
   src = vk_expand_src_stage_flags2(src);
   dst = vk_expand_dst_stage_flags2(dst);
   srca = vk_filter_src_access_flags2(src, srca);
   dsta = vk_filter_dst_access_flags2(dst, dsta);
   return !(srca & ~TILE_SRC_ACCESS) && !(dsta & ~TILE_DST_ACCESS);
#else
   (void)src;
   (void)srca;
   (void)dst;
   (void)dsta;
   (void)exec_only;
   return false;
#endif
}

VKAPI_ATTR void VKAPI_CALL
MALI_PER_ARCH(CmdPipelineBarrier2)(VkCommandBuffer commandBuffer,
                                   const VkDependencyInfo *info)
{
   VK_FROM_HANDLE(mali_cmd_buffer, cmd, commandBuffer);

   VkPipelineStageFlags2 src = 0, dst = 0;
   VkAccessFlags2 srca = 0, dsta = 0;
   bool exec_only = false;   /* some barrier of the call orders execution only */
   for (uint32_t i = 0; i < info->memoryBarrierCount; i++) {
      const VkMemoryBarrier2 *m = &info->pMemoryBarriers[i];
#if PAN_ARCH < 9
      exec_only |=
         execution_only(m->srcStageMask, m->srcAccessMask, m->dstStageMask, m->dstAccessMask);
#endif
      src |= m->srcStageMask;
      dst |= m->dstStageMask;
      srca |= m->srcAccessMask;
      dsta |= m->dstAccessMask;
   }
   /* Queue family transfers need nothing more: one queue family, and the
    * kernel's cache maintenance at atom boundaries covers the external
    * and foreign ones. */
   for (uint32_t i = 0; i < info->bufferMemoryBarrierCount; i++) {
      const VkBufferMemoryBarrier2 *m = &info->pBufferMemoryBarriers[i];
#if PAN_ARCH < 9
      exec_only |=
         execution_only(m->srcStageMask, m->srcAccessMask, m->dstStageMask, m->dstAccessMask);
#endif
      src |= m->srcStageMask;
      dst |= m->dstStageMask;
      srca |= m->srcAccessMask;
      dsta |= m->dstAccessMask;
   }
#if PAN_ARCH < 9
   /* The buffer and global dependencies (an image barrier's access scope
    * is the image), for ubo_copy_dep. */
   const VkPipelineStageFlags2 buf_src = src, buf_dst = dst;
   const VkAccessFlags2 buf_srca = srca, buf_dsta = dsta;
   VkPipelineStageFlags2 img_src = 0, img_dst = 0;
   VkAccessFlags2 img_dsta = 0;
#endif
   for (uint32_t i = 0; i < info->imageMemoryBarrierCount; i++) {
      const VkImageMemoryBarrier2 *m = &info->pImageMemoryBarriers[i];
#if PAN_ARCH < 9
      exec_only |=
         execution_only(m->srcStageMask, m->srcAccessMask, m->dstStageMask, m->dstAccessMask);
      img_src |= m->srcStageMask;
      img_dst |= m->dstStageMask;
      img_dsta |= m->dstAccessMask;
#endif
      src |= m->srcStageMask;
      dst |= m->dstStageMask;
      srca |= m->srcAccessMask;
      dsta |= m->dstAccessMask;
      if (image_barrier_invalidates_crc(m))
         MALI_PER_ARCH(cmd_crc_invalidate)(cmd, container_of(vk_image_from_handle(m->image),
                                                             struct mali_image, vk));
   }

   if (cmd->gfx.render.active) {
      /* Inside a render pass only framebuffer-local dependencies are
       * allowed; the pass's vtc work all runs before its fragment jobs. A
       * by-region fragment-to-fragment dependency is a draw that
       * carries a primitive barrier; without BY_REGION the blob emits
       * nothing. */
      const VkPipelineStageFlags2 fs = FRAG_RENDER_STAGES;
      if ((info->dependencyFlags & VK_DEPENDENCY_BY_REGION_BIT) &&
          (vk_expand_src_stage_flags2(src) & fs) && (vk_expand_dst_stage_flags2(dst) & fs) &&
          !tile_ordered_barrier(src, srca, dst, dsta, exec_only))
         MALI_PER_ARCH(cmd_fb_barrier)(cmd);
      return;
   }
#if PAN_ARCH < 9
   /* The global and buffer dependencies keep the full rule; the image ones
    * apply to the vtc jobs that can touch images. */
   const uint16_t buf_req = barrier_req(buf_src, buf_dst, buf_dsta);
   cmd->jm.req |= buf_req | image_barrier_req(img_src, img_dst, img_dsta);
   if (buf_req & REQ_XVTC_ALL)
      cmd->jm.xvtc_buf = true;
   if (ubo_copy_dep(buf_src, buf_srca, buf_dst, buf_dsta))
      mali_jm_cmd_barrier(cmd, buf_src, buf_srca, VK_PIPELINE_STAGE_2_VERTEX_SHADER_BIT,
                          VK_ACCESS_2_UNIFORM_READ_BIT);
#else
   mali_jm_cmd_barrier(cmd, src, srca, dst, dsta);
#endif
}

/* ---------------------------------------------------------------------- */
/* Begin and end                                                           */

VKAPI_ATTR VkResult VKAPI_CALL
MALI_PER_ARCH(BeginCommandBuffer)(VkCommandBuffer commandBuffer,
                                  const VkCommandBufferBeginInfo *info)
{
   VK_FROM_HANDLE(mali_cmd_buffer, cmd, commandBuffer);

   /* Resets a command buffer recorded before (implicit reset). */
   vk_command_buffer_begin(&cmd->vk, info);
   /* Only command buffers that may run more than once pay for noting
    * what the GPU writes (ARMSX2 records ONE_TIME_SUBMIT only). A command
    * buffer pending twice at once (SIMULTANEOUS_USE) runs its submissions
    * one after the other: one chain cannot run twice at the same time. */
   cmd->jm.resubmit = !(info->flags & VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT);
#if PAN_ARCH < 9
   cmd->jm.xvtc_buf = false;
   cmd->jm.xfer_fresh = false;
   cmd->jm.idx_hint.set = false;
#endif
   return VK_SUCCESS;
}

VKAPI_ATTR VkResult VKAPI_CALL
MALI_PER_ARCH(EndCommandBuffer)(VkCommandBuffer commandBuffer)
{
   VK_FROM_HANDLE(mali_cmd_buffer, cmd, commandBuffer);

   mali_jm_cmd_batch_close(cmd);
   /* What later command buffers' atoms still have to wait for. Waits
    * within one slot are kept by the slot order and the cache maintenance
    * between atoms. */
   const uint16_t req = cmd->jm.req;
   cmd->jm.end_req = 0;
   /* The transfer-only requirements stay transfer-only: in later command
    * buffers only a batch whose vtc chain has a transfer job waits for
    * them (mali_jm_batch::vtc_xfer). Applying them to every vtc atom would
    * hold the next frame's tiling behind all of this frame's fragment work
    * whenever the frame ends with a "colour output -> transfer" barrier
    * whose copy ran on the fragment slot, which is how ARMSX2 ends most
    * frames. */
   if (req & REQ_VTC_AFTER_FRAG)
      cmd->jm.end_req |= MALI_JM_REQ_VTC_AFTER_FRAG;
   else if (req & REQ_XVTC_AFTER_FRAG)
      cmd->jm.end_req |= MALI_JM_REQ_XVTC_AFTER_FRAG;
   if (!(req & REQ_VTC_AFTER_FRAG)) {
      if (req & REQ_VTC_AFTER_FRAG_XFER)
         cmd->jm.end_req |= MALI_JM_REQ_VTC_AFTER_FRAG_XFER;
      else if ((req & REQ_XVTC_AFTER_FRAG_XFER) && !(req & REQ_XVTC_AFTER_FRAG))
         cmd->jm.end_req |= MALI_JM_REQ_XVTC_AFTER_FRAG_XFER;
   }
   if (req & REQ_FRAG_AFTER_VTC)
      cmd->jm.end_req |= MALI_JM_REQ_FRAG_AFTER_VTC;
#if PAN_ARCH < 9
   /* An image barrier's requirements likewise stay for the later vtc
    * chains that can touch images (mali_jm_batch::vtc_img). */
   if (!(req & REQ_VTC_AFTER_FRAG)) {
      if (req & REQ_IVTC_AFTER_FRAG)
         cmd->jm.end_req |= MALI_JM_REQ_IVTC_AFTER_FRAG;
      else if (req & REQ_IVTC_AFTER_FRAG_XFER)
         cmd->jm.end_req |= MALI_JM_REQ_IVTC_AFTER_FRAG_XFER;
   }
   if (cmd->jm.xvtc_buf &&
       (cmd->jm.end_req & (MALI_JM_REQ_XVTC_AFTER_FRAG | MALI_JM_REQ_XVTC_AFTER_FRAG_XFER)))
      cmd->jm.end_req |= MALI_JM_REQ_XVTC_BUF;
   cmd->jm.xvtc_buf = false;
#endif
   cmd->jm.req = 0;
   return vk_command_buffer_end(&cmd->vk);
}

/* ---------------------------------------------------------------------- */
/* Command buffer objects                                                  */

static void
cmd_clear(struct mali_cmd_buffer *cmd)
{
   /* Timestamps live in command memory (below, release_memory): read them
    * before it goes. */
   mali_jm_measure_cmd_reset(cmd);
   util_dynarray_clear(&cmd->jm.batches);
   util_dynarray_clear(&cmd->jm.frags);
   util_dynarray_clear(&cmd->jm.resets);
   util_dynarray_clear(&cmd->jm.reset_data);
   util_dynarray_clear(&cmd->jm.oq_done);
   cmd->jm.open = false;
#if PAN_ARCH < 9
   mali_v7_idraw_arena_release(cmd);
   cmd->jm.pend_tilers = 0;
   cmd->jm.pend_tiler_ns = 0;
   cmd->jm.tiler_defer = false;
   cmd->jm.copy_tsd = 0;
   util_dynarray_clear(&cmd->jm.buf_writes);
#endif
   cmd->jm.req = cmd->jm.end_req = 0;
   cmd->jm.resubmit = false;
   cmd->jm.submitted = false;
   cmd->jm.last_seq = 0;
   release_memory(cmd);
   memset(cmd->push_constants, 0, sizeof(cmd->push_constants));
   memset(&cmd->compute, 0, sizeof(cmd->compute));
   memset(&cmd->gfx, 0, sizeof(cmd->gfx));
   cmd->gfx.draw.dirty = MALI_GFX_DIRTY_ALL;
   cmd->dispatches = cmd->draws = cmd->passes = 0;
#if PAN_ARCH < 9
   /* The v7 draw state goes with gfx: its descriptor tables were in the
    * command memory released above (a draw after the reset must not keep
    * them, mali_v7_desc_refresh), its index buffer view belongs to the
    * binding in gfx.draw.ib, and everything else is rebuilt by
    * MALI_GFX_DIRTY_ALL. */
   mali_jm_draw_tmpl_init(&cmd->jm.draw);
#endif
}

static VkResult
cmd_create(struct vk_command_pool *pool, VkCommandBufferLevel level,
           struct vk_command_buffer **out)
{
   struct mali_device *dev = container_of(pool->base.device, struct mali_device, vk);
   struct mali_cmd_buffer *cmd =
      vk_zalloc(&pool->alloc, sizeof(*cmd), alignof(struct mali_cmd_buffer),
                VK_SYSTEM_ALLOCATION_SCOPE_OBJECT);
   if (!cmd)
      return vk_error(dev, VK_ERROR_OUT_OF_HOST_MEMORY);

   VkResult result =
      vk_command_buffer_init(pool, &cmd->vk, &MALI_PER_ARCH(cmd_buffer_ops), level);
   if (result != VK_SUCCESS) {
      vk_free(&pool->alloc, cmd);
      return result;
   }
   cmd->dev = dev;
   util_dynarray_init(&cmd->jm.batches, NULL);
   util_dynarray_init(&cmd->jm.frags, NULL);
   util_dynarray_init(&cmd->jm.resets, NULL);
   util_dynarray_init(&cmd->jm.reset_data, NULL);
   util_dynarray_init(&cmd->jm.oq_done, NULL);
#if PAN_ARCH < 9
   util_dynarray_init(&cmd->jm.buf_writes, NULL);
#endif
   list_inithead(&cmd->slabs);
   mali_jm_draw_tmpl_init(&cmd->jm.draw);
   cmd->vk.dynamic_graphics_state.vi = &cmd->dyn_vi;
   cmd->vk.dynamic_graphics_state.ms.sample_locations = &cmd->dyn_sl;
   cmd->gfx.draw.dirty = MALI_GFX_DIRTY_ALL;
   mali_jm_measure_cmd_create(cmd);
   *out = &cmd->vk;
   return VK_SUCCESS;
}

static void
cmd_reset(struct vk_command_buffer *vk_cmd, VkCommandBufferResetFlags flags)
{
   struct mali_cmd_buffer *cmd = container_of(vk_cmd, struct mali_cmd_buffer, vk);
   vk_command_buffer_reset(&cmd->vk);
   cmd_clear(cmd);
}

static void
cmd_destroy(struct vk_command_buffer *vk_cmd)
{
   struct mali_cmd_buffer *cmd = container_of(vk_cmd, struct mali_cmd_buffer, vk);
   mali_jm_measure_cmd_destroy(cmd);
#if PAN_ARCH < 9
   mali_v7_idraw_arena_release(cmd);
#endif
   release_memory(cmd);
   util_dynarray_fini(&cmd->jm.batches);
   util_dynarray_fini(&cmd->jm.frags);
   util_dynarray_fini(&cmd->jm.resets);
   util_dynarray_fini(&cmd->jm.reset_data);
   util_dynarray_fini(&cmd->jm.oq_done);
#if PAN_ARCH < 9
   util_dynarray_fini(&cmd->jm.buf_writes);
#endif
   mali_push_shadows_fini(&cmd->push_shadow, &cmd->vk.pool->alloc);
   vk_command_buffer_finish(&cmd->vk);
   vk_free(&cmd->vk.pool->alloc, cmd);
}

const struct vk_command_buffer_ops MALI_PER_ARCH(cmd_buffer_ops) = {
   .create = cmd_create,
   .reset = cmd_reset,
   .destroy = cmd_destroy,
};
